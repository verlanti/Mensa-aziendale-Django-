from django.apps import AppConfig


class accountsConfig(AppConfig):
    name = 'accounts'
